About Babel
===========

Babel is a Python library that provides an integrated collection of
utilities that assist with internationalizing and localizing Python
applications (in particular web-based applications.)

Details can be found in the HTML files in the `doc` folder.

For more information please visit the Babel web site:

  <http://babel.edgewall.org/>
